/* tasks.h
   ======= */

#define ERRLOG_NAME "errlog"
#define SCHEDULER_NAME "schedule"
#define CONTROL_NAME "control_program"
#define TASK_NAMES "echo_data","raw_write","fit_write"
