/* site.h
   ====== */


void start_program();
int start_scan();
void integrate();
void end_program();
