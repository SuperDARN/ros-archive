/* radar.h
   ======= */


int radar_s(int debug,int *lagsA,int *lagsB);

 
