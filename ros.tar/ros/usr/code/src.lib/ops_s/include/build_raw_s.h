/* build_raw_s.h
   ============= */

void build_raw_s(int chn,struct rawdata *raw,int *ptab,int *lags);
