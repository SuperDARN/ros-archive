/* shell_s.h
   ========= */

void init_shell_s();

