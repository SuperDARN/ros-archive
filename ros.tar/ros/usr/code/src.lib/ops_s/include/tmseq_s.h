/* tmseq_s.h
   ========= */

int time_seq(int channel,pid_t dio_id,struct tsg_table *ptr,int *patn);
  
 
