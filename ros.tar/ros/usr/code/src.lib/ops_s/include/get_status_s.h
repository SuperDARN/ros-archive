/* get_status_s.h
   ============== */

void get_status(int chn,int clear);

 
