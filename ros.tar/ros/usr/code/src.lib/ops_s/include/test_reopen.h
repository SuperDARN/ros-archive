/* test_reopen.h
   ============= */

int test_reopen(int hbnd,int mtbnd,int scbnd);
 