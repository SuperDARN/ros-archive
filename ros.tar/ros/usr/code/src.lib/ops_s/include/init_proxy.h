/* init_proxy.h
   ============ */

pid_t init_proxy(char *name);
