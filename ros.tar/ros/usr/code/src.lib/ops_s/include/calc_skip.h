/* calc_skip.h
   =========== */


int calc_skip(float bnd);

 