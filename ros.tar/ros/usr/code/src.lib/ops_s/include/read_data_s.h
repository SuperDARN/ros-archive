/* read_data_s.h
   ============= */
 
int read_data_s(int chn,struct rawfp *fp); 
