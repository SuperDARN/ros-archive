/* wait_boundary.h
   =============== */

int wait_boundary(float bnd);
 