/* stereo.h
   ======== */

#define MAX_AD_BUF 16