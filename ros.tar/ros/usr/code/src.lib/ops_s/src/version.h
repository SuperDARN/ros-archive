/* version.h
   ========= */

#define VMAJOR 1
#define VMINOR 66
 