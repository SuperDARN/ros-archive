/* build_raw.h
   =========== */

void build_raw(struct rawdata *raw,int *ptab,int *lags);
