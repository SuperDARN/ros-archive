/* get_status.h
   ============ */

void get_status(int clear);

 