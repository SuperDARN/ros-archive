/* read_data.h
   =========== */
 
int read_data(struct rawfp *fp); 