/* shell.h
   ======= */

void init_shell();

