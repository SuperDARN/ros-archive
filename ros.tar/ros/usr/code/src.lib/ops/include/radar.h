/* radar.h
   ======= */


int radar(int debug,int *lags);

 