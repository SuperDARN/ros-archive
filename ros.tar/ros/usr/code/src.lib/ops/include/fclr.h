/* fclr.h
   ====== */

extern int fclr_id[2];
extern struct freq_table *frq_table;
int fclr(int debug,int start_freq,int end_freq,int step_freq);
 