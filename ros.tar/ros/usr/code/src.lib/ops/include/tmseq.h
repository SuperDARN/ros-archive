/* time_seq.h
   ========== */

int time_seq(pid_t dio_id,struct tsg_table *ptr,int *patn);
  
 