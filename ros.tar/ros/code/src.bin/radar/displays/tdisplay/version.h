/*version.h
  =========*/

#define VERSION 6.25
#define VSTRING "6.25"
#define VMAJOR 6
#define VMINOR 25
