/* errstr.h
   ======== */
  
char *errstr[]={
    "Usage: make_delta [-b bmnum] [-f fname] host port\n",
    0};






