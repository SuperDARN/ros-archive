/* log_info.h
   ========== */

void log_info(int flg,char *str);


