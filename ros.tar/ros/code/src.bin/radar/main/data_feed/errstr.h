/* errstr.h
   ======== */

char *errstr[]={
 "Usage: data_feed [-o time] [-d] [-r] [-s st_id] [-i intt] [taskname...] fname\n",
  0};
