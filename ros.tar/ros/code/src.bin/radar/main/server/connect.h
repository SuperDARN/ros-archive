/* connect.h
   ========= */

void close_sock(int i);
int open_sock(int sock,struct fd_set *fdset);
