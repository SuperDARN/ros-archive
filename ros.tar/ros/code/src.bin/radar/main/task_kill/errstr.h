/* errstr.h
   ======== */

char *errstr[]={
  "Usage: close_file task\n",
  0};

