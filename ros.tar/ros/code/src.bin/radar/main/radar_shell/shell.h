/* shell.h 
   ======= */

int shell(char *buffer,char *pflag);
 
