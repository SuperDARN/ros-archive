/*version.h
  =========*/

#define VERSION 2.3
#define VSTRING "2.3"
#define VMAJOR 2
#define VMINOR 3
