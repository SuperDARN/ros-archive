#define TASK_NAME "fit_write"
#define ERRLOG "errlog"
