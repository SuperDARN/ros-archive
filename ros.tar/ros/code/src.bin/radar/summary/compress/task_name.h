#define ERRLOG "errlog"
#define ECHO_DATA "echo_data"
#define TASK_NAME "compress"
