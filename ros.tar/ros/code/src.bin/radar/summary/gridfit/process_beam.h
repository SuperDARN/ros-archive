/* process_beam.h
  =============== */

void zero_scan(struct radardata *scan);
void process_beam(struct fitdata *fit,struct radardata *scan);
