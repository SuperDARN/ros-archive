/*version.h
  =========*/

#define VERSION 6.5
#define VSTRING "6.5"
#define VMAJOR 6
#define VMINOR 5
