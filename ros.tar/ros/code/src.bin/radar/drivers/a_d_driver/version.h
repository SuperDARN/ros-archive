/*version.h
  =========*/

#define VERSION 3.26
#define VSTRING "3.26"
#define VMAJOR 3
#define VMINOR 26
