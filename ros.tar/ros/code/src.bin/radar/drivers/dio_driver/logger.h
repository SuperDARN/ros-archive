/* logger.h
   ========*/


FILE *open_log(void);
