/* bcd.h
   ===== */

unsigned char get_bcd(unsigned char x, unsigned char m,int s);
void binary_bcd(unsigned int a,unsigned char *digits);
