/* cnv_freq.h
   ========== */

void cnv_freq(int freq,unsigned char *ptr);
