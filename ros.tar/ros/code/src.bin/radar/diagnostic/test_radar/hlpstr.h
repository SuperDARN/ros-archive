/* hlpstr.h
   ======== */


char *hlpstr[]={
   "Help Information Goes Here\n",
   NULL};
