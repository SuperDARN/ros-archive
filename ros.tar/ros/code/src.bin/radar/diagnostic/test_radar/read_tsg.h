/* read_tsg.h 
   ========== */

#define MAX_TSG 16000


int read_tsg(FILE *fp);
