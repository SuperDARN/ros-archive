/* hlpstr.h
   ======== */


char *hlpstr[]={
   "cat_raw - Concatenate together two or more raw (dat) files.\n\n",
  "Usage: cat_raw [--help] inrawfile... outrawfile\n\n",
  "--help\tgive this message\n",
  "inrawfile\tlist of raw files to concatenate\n",
  "outrawfile\tname of raw file to create\n",
   NULL};
