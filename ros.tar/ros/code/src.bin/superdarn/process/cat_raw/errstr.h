/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: cat_raw [--help] inrawfile... outrawfile\n",
   0
};



