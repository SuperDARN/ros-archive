/* version.h
   ========= */


#define VSTRING "5.0"
