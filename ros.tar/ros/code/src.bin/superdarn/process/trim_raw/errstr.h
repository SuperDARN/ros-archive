/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: trim_raw [--help] [-t threshold] [-st hr:mn] [-et hr:mn]\n",
   "                [-ex hr:mn] inrawfile outrawfile\n",
   0
};



