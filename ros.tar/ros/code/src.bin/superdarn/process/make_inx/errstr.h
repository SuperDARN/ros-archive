/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: make_inx [--help] fitfile inxfile\n",
   0
};



