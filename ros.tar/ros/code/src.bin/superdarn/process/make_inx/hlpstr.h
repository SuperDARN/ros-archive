/* hlpstr.h
   ======== */


char *hlpstr[]={
   "make_inx - Regenerates an index file for a fit file.\n\n",
  "Usage: make_inx [--help] fitfile inxfile\n\n",
  "--help\tgive this message\n",
  "fitfile\tname of fit file to open\n",
  "inxfile\tname of inx file to create\n",
   NULL};
