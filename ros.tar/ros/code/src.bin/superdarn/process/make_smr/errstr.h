/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: make_smr [--help] [-vb] [-t pwr] [-b {blst}] fitfile\n",
   0
};



