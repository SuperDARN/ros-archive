/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: trim_fit [--help] [-st hr:mn] [-et hr:mn]\n",
   "                [-ex hr:mn] infitfile [ininxfile] outfitfile\n",
   "       trim_fit [--help] -i [-st hr:mn] [-et hr:mn]\n",
   "                [-ex hr:mn] infitfile [ininxfile] outfitfile outinxfile\n",
   0
};



