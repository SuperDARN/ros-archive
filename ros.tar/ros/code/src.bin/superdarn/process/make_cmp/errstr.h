/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: make_cmp [--help] [-vb] [-a] [-p max] [-v max] [-w max] [-t pwr]\n",
   "                [-b bm] fitfile\n",
   0
};



