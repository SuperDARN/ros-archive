/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: make_fit [--help] [-vb] rawfile fitfile [inxfile]\n",
   0
};
