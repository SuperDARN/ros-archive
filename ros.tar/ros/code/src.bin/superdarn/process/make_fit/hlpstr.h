/* hlpstr.h
   ======== */


char *hlpstr[]={
   "make_fit - Creates a fit file from a raw (dat) file\n\n",
   "Usage: make_fit [--help] [-vb] rawfile fitfile [inxfile]\n\n",
   "--help\tgive this message\n",
   "--vb\tverbose. Log status to the standard error\n"
   "rawfile\traw file to process\n",
   "fitfile\tfit file to create\n",
   "inxfile\tinx file to create, if required.\n",             
   NULL};
