/* errstr.h
   ======== */

char *errstr[]={ 
   "Usage: cat_fit [--help] infitfile... outfitfile\n",
   "       cat_fit [--help] -i infitfile... outfitfile outinxfile\n",
   0
};



