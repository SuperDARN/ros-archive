/* print_info.h
   ============ */

void print_info(FILE *fp,char *str[]);
