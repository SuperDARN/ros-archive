/* read_clock.h 
   ============ */

#ifndef _READ_CLOCK_H
#define _READ_CLOCK_H

int read_clock(int *yr,int *month,int *day,int *hour,int *min,int *sec,
               int *msec,int *usec);

#endif

