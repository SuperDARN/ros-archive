/* test_file.h 
   =========== */

#ifndef _TEST_FILE_H
#define _TEST_FILE_H

int test_file(char *fname);

#endif

