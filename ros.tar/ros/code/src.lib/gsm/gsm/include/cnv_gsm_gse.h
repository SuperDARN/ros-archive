/* cnv_gsm_gse.h
   ============= */

void cnv_gsm_gse(int year,int month,int day,int hour,int min,double sec,
                double *bgsm,double *bgse) ;
   
  







