/* cnv_geo_gsm.h
   ============= */

void cnv_geo_gsm(int year,int month,int day,int hour,int min,double sec,
                double *bgeo,double *bgsm) ;
   
  







