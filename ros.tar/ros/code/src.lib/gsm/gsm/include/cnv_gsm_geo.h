/* cnv_gsm_geo.h
   ============= */

void cnv_gsm_geo(int year,int month,int day,int hour,int min,double sec,
                double *bgsm,double *bgeo) ;
   
  







