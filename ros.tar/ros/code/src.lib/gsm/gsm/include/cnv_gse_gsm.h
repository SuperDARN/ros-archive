/* cnv_gse_gsm.h
   ============= */

void cnv_gse_gsm(int year,int month,int day,int hour,int min,double sec,
                double *bgse,double *bgsm) ;
   
  







