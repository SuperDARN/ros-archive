/* cnv_gsm_sm.h
   ============ */

void cnv_gsn_sm(int year,int month,int day,int hour,int min,double sec,
                double *bgsm,double *bsm) ;
   
  







