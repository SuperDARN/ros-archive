/* dma-addr.h 
   ========== */

#ifndef _DMA_ADDR
#define _DMA_ADDR
extern int dmaaddr(dma_t *dbuf,pid_t task_id);
#endif


