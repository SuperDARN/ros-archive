/* normalize.h
   =========== */


void normalize(int *pwr0,int *acfd,int *xcfd,int nrang,int mplgs);


