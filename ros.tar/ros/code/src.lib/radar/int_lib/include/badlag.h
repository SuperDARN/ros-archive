/* badlag_zero.h
   ============== */

int badlag_zero(struct tsg_parms *prm,int mplgs,int *lag_table);

