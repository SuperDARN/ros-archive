/* sum_power.h 
   =========== */

int sum_power(struct tsg_parms *prm,int mplgs,int *lag_table,
			  int *acf_pwr0,int mxpwr,
			  int16 *in_buf,int range_offset,
			  int change_atten,int bad_range);
