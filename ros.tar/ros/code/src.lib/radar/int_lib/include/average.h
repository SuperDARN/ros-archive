/* average.h 
   ========= */


int average(int *pwr0,int *acfd,int *xcfd,int nave,int nrang,int mplgs);
