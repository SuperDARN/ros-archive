/* file_io.h
   ========= */

#ifndef _FILE_IO
#define FILE_IO

char *open_file(char *pathenv,
                double etime,char code,
                char *ext,int mode,char *sfx,int flag);
#endif
