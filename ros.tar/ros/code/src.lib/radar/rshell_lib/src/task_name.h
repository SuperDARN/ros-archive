#define CONTROL_NAME "control_program"
#define SCHEDULE_NAME "schedule"