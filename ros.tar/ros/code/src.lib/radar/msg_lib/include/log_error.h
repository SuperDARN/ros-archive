/* log_error.h
   =========== */

#ifndef _LOG_ERROR
int log_error(struct task_id *ptr,char *name,char *buffer);
#define _LOG_ERROR
#endif