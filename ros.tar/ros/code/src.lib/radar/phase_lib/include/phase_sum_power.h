/* sum_power.h 
   =========== */

int sum_power(struct tsg_parms *prm,int mplgs,int *lag_table,
			  int *acf_pwr0,int mxpwr,
			  int *d_data,int range_offset,
			  int change_atten,int bad_range);
