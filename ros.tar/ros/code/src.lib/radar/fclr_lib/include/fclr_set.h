/* fclr_set.h
   ========== */

int fclr_set(pid_t dio_id,struct tsg_table *ptr,int *tsg_id);
