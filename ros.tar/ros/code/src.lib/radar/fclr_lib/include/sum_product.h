/* sum_product.h
   ============= */

int sum_product(int16 *buffer,int *ave_power,
				int num_samples,int *mxpwr);
