/* filer.h 
   ======= */

#ifndef _UTIL_FILER
#define FILER_STRING 256

int filer(char *,char *,char *,char *);
char *leaf_name(char *);

#define _UTIL_FILER
#endif
