/* cgm_to_altitude.h 
   ================= */

int cgm_to_altitude(double,double,double *);
    
