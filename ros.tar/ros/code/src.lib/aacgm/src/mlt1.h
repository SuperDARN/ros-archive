/* mlt1.h
   ====== */

double mlt1(int t0,double solar_dec,double mlon,double *mslon);

