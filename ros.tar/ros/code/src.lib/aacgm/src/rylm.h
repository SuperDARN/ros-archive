/* rlym.h
   ====== */

int rylm(double colat,double lon,int order,
	  double *ylmval);
   
  
