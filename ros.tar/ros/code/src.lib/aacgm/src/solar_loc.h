/* solar_loc.h
   =========== */

int solar_loc(int yr,int t1,double *mean_lon,double *dec);

  
