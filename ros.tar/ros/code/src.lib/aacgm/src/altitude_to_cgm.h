/* altitude_to_cgm.h
   ================= */

void altitude_to_cgm(double,double,double *);
   
  
