/* mlt.h
   ===== */

double mlt(int yr,int t0,double mlong, double *mslong);




