/* eqn_of_time.h
   ============= */

double eqn_of_time(double mean_lon,int yr);

  
