/* fit_read_inx.h
   ============== */

int fit_read_inx(struct fitfp *ptr,int32 *buffer,int recno);
 
