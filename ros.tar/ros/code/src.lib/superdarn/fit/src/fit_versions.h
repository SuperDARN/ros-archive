/* fit_versions.h
   ============== */

int fit_read_current(struct fitfp *ptr,struct fitdata *fit_data);
 


