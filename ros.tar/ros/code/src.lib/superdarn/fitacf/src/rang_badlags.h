/* rang_badlags.h
   ============== */

void r_overlap(struct fit_prm *ptr);
void lag_overlap(int range,int *badlag,struct fit_prm *ptr);
