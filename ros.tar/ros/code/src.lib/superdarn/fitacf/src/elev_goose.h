/* elev_goose.h
   ============ */

double elev_goose(struct fit_prm *prm,double range, double phi0);
