/* more_badlags.h
   ============== */ 

double more_badlags(double *w,int *badlag,
                   double noise_lev,int mplgs,int nave);
