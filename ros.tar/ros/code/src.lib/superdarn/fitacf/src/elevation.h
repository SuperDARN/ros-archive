/* elevation.h
   =========== */

double elevation(struct fit_prm *prm,double range,double phi0);
