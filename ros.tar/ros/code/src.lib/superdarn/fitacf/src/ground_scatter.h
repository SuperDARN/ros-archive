/* ground_scatter.h
   ================ */

int ground_scatter (struct range_data *ptr);
