/* dbl_cmp.h
   ========= */

int dbl_cmp(double *x,double *y);
