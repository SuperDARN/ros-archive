/* badsmp.h
   ======== */

struct badsmp {
  int nbad;
  int badsmp[50];
};
      