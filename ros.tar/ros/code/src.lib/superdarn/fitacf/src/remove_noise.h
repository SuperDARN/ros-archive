/* remove_noise.h
   ============== */

void remove_noise(int mplgs,struct complex *acf,
				  struct complex *ncf);
