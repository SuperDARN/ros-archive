/* calc_phi_res.h
   ============== */


void calc_phi_res(struct complex *acf,int *badlag,
				  double *phi_res,int mplgs);
