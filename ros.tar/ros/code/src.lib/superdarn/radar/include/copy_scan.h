/* copy_scan.h
   =========== */

void copy_scan(struct radardata *dst,
	      struct radardata *src);

 
