/* id.h
   ==== */

#ifndef _RADAR_ID_H
#define _RADAR_ID_H

#define GOOSEBAY 1
#define SCHEFFERVILLE 2
#define KAPUSKASING 3
#define HALLEY 4
#define SASKATOON 5
#define PRINCEALBERT 6
#define KODIAK 7
#define ICEWEST 8
#define ICEEAST 9
#define FINLAND 10
#define SANAE 11
#define SYOWA 12
#define SYOWAEAST 13
#define TIGER 14
#define KERGUELEN 15

#endif
