/* geodtgc.h
   ========= */

void geodtgc(int iopt,double *gdlat,double *gdlon,
             double *grho,double *glat,
			 double *glon,double *del);

 
