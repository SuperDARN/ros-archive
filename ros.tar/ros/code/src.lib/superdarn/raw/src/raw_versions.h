/* raw_versions.h
   ============== */

int raw_read_current(struct rawfp *ptr,struct rawdata *raw_data);
 
