/* check_ops.h
   =========== */

#ifndef _FILTER_CHECK_OPS_H
#define _FILTER_CHECK_OPS_H

#ifndef _RADAR_SCAN_H
#include "radar_scan.h"
#endif


int check_ops(struct radardata *input);
#endif
 


