/* error.h
   ======= */

double find_error(struct cell *cell,double (*prmfn)(struct datapoint *));


















