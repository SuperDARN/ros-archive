/* cell.h
   ====== */

struct cell {
  int cnt;
  unsigned char *sct;
  struct datapoint *data;
};














