/* magcmp.h
   ======== */

int magcmp(double date, double frho, double flat, double flon, 
           double *bx, double *by, double *bz, double *b);
