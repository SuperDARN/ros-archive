/* igrfcall.h
   ========== */

int igrfcall(double date, double flat, double flon, 
              double elev, double *x, double *y, double *z);
 


