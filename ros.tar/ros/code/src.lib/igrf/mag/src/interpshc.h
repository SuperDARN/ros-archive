/* interpshc.h
   =========== */


int interpshc(double date, 
              double dte1, 
              int nmax1, double *gh1, 
              double dte2, double nmax2, 
              double *gh2, int *nmax, double *gh);
    
  
