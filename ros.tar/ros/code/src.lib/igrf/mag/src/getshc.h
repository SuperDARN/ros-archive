/* getshc.h
   ======== */

int getshc(char *fname,int *nmax,double *erad,double *gh);

 

