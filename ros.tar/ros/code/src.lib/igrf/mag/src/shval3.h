/* shval3.h
   ======== */

int shval3(int igdgc, double flat,double flon, double elev, 
            double erad, double a2, double b2, int nmax, double *gh,
            int iext,double *ext,double *x,double *y,double *z);
 
   
