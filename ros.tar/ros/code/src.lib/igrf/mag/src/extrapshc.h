/* extrapshc.h
   =========== */

int extrapshc(double date, double dte1, int nmax1, 
               double *gh1, int nmax2, double *gh2, int *nmax, double *gh);
   
